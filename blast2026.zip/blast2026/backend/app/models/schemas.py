"""Pydantic request/response schemas."""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, EmailStr, Field, field_validator


class EventName(str, Enum):
    AI_HACKATHON = "AI Hackathon"
    WEB_DEV = "Web Development Challenge"
    UIUX = "UI/UX Design"
    PAPER_PRESENTATION = "Paper Presentation"
    PROJECT_EXPO = "Project Expo"
    TECH_QUIZ = "Tech Quiz"


class RegistrationCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    phone: str = Field(min_length=10, max_length=10)
    college: str = Field(min_length=2, max_length=150)
    department: str = Field(min_length=2, max_length=100)
    year: str = Field(min_length=2, max_length=20)
    event: EventName
    uid: str | None = None

    @field_validator("phone")
    @classmethod
    def phone_must_be_digits(cls, value: str) -> str:
        if not value.isdigit():
            raise ValueError("Phone number must contain only digits.")
        return value


class RegistrationResponse(BaseModel):
    success: bool
    message: str
    registration_id: str


class RegistrationRecord(BaseModel):
    id: str
    name: str
    email: str
    phone: str
    college: str
    department: str
    year: str
    event: str
    uid: str | None = None
    createdAt: str


class RegistrationListResponse(BaseModel):
    count: int
    registrations: list[RegistrationRecord]


class HealthResponse(BaseModel):
    status: str
    service: str
    timestamp: str


def utc_now_iso() -> str:
    return datetime.utcnow().isoformat() + "Z"
