"""Registration routes backed by Firestore."""

from fastapi import APIRouter, HTTPException, Query
from google.cloud.firestore import Client as FirestoreClient

from app.firebase import get_firestore_client
from app.models.schemas import (
    RegistrationCreate,
    RegistrationListResponse,
    RegistrationRecord,
    RegistrationResponse,
    utc_now_iso,
)

router = APIRouter(tags=["registrations"])

REGISTRATIONS_COLLECTION = "registrations"
USERS_COLLECTION = "users"


@router.post(
    "/register",
    response_model=RegistrationResponse,
    status_code=201,
    summary="Submit a new event registration",
)
def create_registration(payload: RegistrationCreate) -> RegistrationResponse:
    try:
        db: FirestoreClient = get_firestore_client()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            status_code=503,
            detail="Registration service is temporarily unavailable. Please try again shortly.",
        ) from exc

    created_at = utc_now_iso()
    record = payload.model_dump(mode="json")
    record["createdAt"] = created_at

    try:
        doc_ref = db.collection(REGISTRATIONS_COLLECTION).document()
        doc_ref.set(record)

        if payload.uid:
            db.collection(USERS_COLLECTION).document(payload.uid).set(
                {
                    "name": payload.name,
                    "email": payload.email,
                    "lastRegisteredEvent": payload.event.value,
                    "lastRegisteredAt": created_at,
                },
                merge=True,
            )
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            status_code=500,
            detail="Failed to save registration. Please try again.",
        ) from exc

    return RegistrationResponse(
        success=True,
        message="Registration successful!",
        registration_id=doc_ref.id,
    )


@router.get(
    "/registrations",
    response_model=RegistrationListResponse,
    summary="List registrations, optionally filtered by user uid",
)
def list_registrations(
    uid: str | None = Query(default=None, description="Filter registrations by Firebase user uid"),
) -> RegistrationListResponse:
    try:
        db: FirestoreClient = get_firestore_client()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            status_code=503,
            detail="Registration service is temporarily unavailable. Please try again shortly.",
        ) from exc

    query = db.collection(REGISTRATIONS_COLLECTION)
    if uid:
        query = query.where("uid", "==", uid)

    try:
        docs = list(query.order_by("createdAt", direction="DESCENDING").stream())
    except Exception:
        # Firestore requires a composite index for filter + order_by combos;
        # fall back to an unordered query and sort in-memory if that happens.
        docs = list(query.stream())
        docs.sort(key=lambda d: d.to_dict().get("createdAt", ""), reverse=True)

    registrations = [
        RegistrationRecord(id=doc.id, **doc.to_dict()) for doc in docs
    ]

    return RegistrationListResponse(count=len(registrations), registrations=registrations)
