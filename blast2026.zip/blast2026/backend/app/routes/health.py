"""Health and root informational routes."""

from datetime import datetime

from fastapi import APIRouter

from app.models.schemas import HealthResponse

router = APIRouter(tags=["health"])


@router.get("/", summary="API root")
def read_root() -> dict[str, str]:
    return {
        "message": "BLAST 2026 API is running.",
        "docs": "/docs",
    }


@router.get("/health", response_model=HealthResponse, summary="Health check")
def health_check() -> HealthResponse:
    return HealthResponse(
        status="ok",
        service="blast-2026-backend",
        timestamp=datetime.utcnow().isoformat() + "Z",
    )
