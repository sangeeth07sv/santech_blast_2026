"""BLAST 2026 FastAPI application entrypoint."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.routes import health, register

settings = get_settings()

app = FastAPI(
    title="BLAST 2026 API",
    description="Backend API for the BLAST 2026 technical symposium — RVS Institute of Technology.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(register.router)
