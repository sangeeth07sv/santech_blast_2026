"""Firebase Admin SDK initialization and Firestore client access."""

import json
from functools import lru_cache

import firebase_admin
from firebase_admin import credentials, firestore
from google.cloud.firestore import Client as FirestoreClient

from app.config import get_settings


def _build_credentials() -> credentials.Base:
    settings = get_settings()

    if settings.firebase_service_account_json:
        service_account_info = json.loads(settings.firebase_service_account_json)
        return credentials.Certificate(service_account_info)

    if settings.google_application_credentials:
        return credentials.Certificate(settings.google_application_credentials)

    # Falls back to Application Default Credentials if available in the
    # deployment environment (e.g. GCP-managed runtimes).
    return credentials.ApplicationDefault()


@lru_cache
def get_firebase_app() -> firebase_admin.App:
    if not firebase_admin._apps:  # noqa: SLF001
        cred = _build_credentials()
        firebase_admin.initialize_app(cred)
    return firebase_admin.get_app()


@lru_cache
def get_firestore_client() -> FirestoreClient:
    get_firebase_app()
    return firestore.client()
